const APP_TITLE = "Movie App";
const API_KEY = import.meta.env.VITE_COOL_BUG;
const IMG_URL = "https://image.tmdb.org/t/p/";


export {APP_TITLE, API_KEY, IMG_URL}